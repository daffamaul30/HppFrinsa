package frinsa.hpp

data class Blok(
    var id:Int = 0,
    var name:String = ""
)