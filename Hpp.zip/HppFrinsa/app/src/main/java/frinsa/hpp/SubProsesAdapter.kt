package frinsa.hpp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import frinsa.hpp.daftar_produksi.ModelDaftarProduksi
import kotlinx.android.synthetic.main.card_daftar_produksi.view.*

class SubProsesAdapter (val context: Context?, private val dpList: MutableList<ModelDaftarProduksi>): RecyclerView.Adapter<SubProsesAdapter.cardViewProses>(){
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): cardViewProses {
        return cardViewProses(LayoutInflater.from(context).inflate(R.layout.cardviewproses,parent,false))
    }

    override fun getItemCount(): Int = dpList.size

    inner class cardViewProses(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(modelDaftarProses: ModelDaftarProduksi){
            itemView.dp_tv_tgl.text = modelDaftarProses.tanggal
            itemView.dp_tv_blok.text = modelDaftarProses.blok
            itemView.dp_tv_varietas.text = modelDaftarProses.varietas
            itemView.dp_tv_berat.text = modelDaftarProses.berat.toString()
            itemView.dp_tv_proses.text = modelDaftarProses.proses
            itemView.dp_tv_biaya.text = modelDaftarProses.biaya.toString()
            itemView.dp_tv_tahap.text = modelDaftarProses.tahap
        }
    }
    override fun onBindViewHolder(holder: cardViewProses, position: Int) {
        holder.bind(dpList[position])
    }
}