package frinsa.hpp

data class Cherry(
    var id:Int = 0,
    var id2:Int = 0,
    var berat: Double = 0.0,
    var biaya: Int = 0
)