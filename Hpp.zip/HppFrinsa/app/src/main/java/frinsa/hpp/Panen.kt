package frinsa.hpp

data class Panen(
    var id:Int = 0,
    var tanggal:String = "",
    var varietas: String = "",
    var blok: String = "",
    var kolektif: String = "",
    var proses: String = "",
    var status: String = ""
)