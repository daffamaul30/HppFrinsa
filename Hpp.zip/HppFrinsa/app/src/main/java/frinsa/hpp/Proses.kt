package frinsa.hpp

data class Proses(
    var id:Int = 0,
    var name:String = ""
)