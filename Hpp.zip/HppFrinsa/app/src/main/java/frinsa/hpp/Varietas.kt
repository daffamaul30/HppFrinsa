package frinsa.hpp

data class Varietas(
    var id:Int = 0,
    var name:String = ""
)